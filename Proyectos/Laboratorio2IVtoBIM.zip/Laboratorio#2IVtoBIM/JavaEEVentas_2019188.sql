/*
Nombre: Héctor Javier Rodríguez Cabrera
Carné: 2019188
Codigo Técnicp: IN5BM
Fecha de inicio: 17 de Julio de 2023 - 15:40
*/

drop database if exists JavaEEVentas2019188;
create database JavaEEVentas2019188;

use JavaEEVentas2019188;

Create table Cliente(
	codigoCliente int not null auto_increment,
    DPICliente varchar(15) not null,
    nombresCliente varchar(200) not null,
    direccionCliente varchaR(150) not null,
    estado varchar(1) not null,
    primary key PK_codigoCliente (codigoCliente)
);	

Create table Empleado(
	codigoEmpleado int not null auto_increment,
	DPIEmpleado int not null,
    nombresEmpleado varchar(200) not null,
    telefonoEmpleado varchar(8) not null,
    foto blob,
    estado varchar(1) not null,
    usuario varchar(15) not null,
    primary key PK_codigoEmpleado (codigoEmpleado)
);

Create table Producto( 
	codigoProducto int not null auto_increment,
    nombreProducto varchar(200) not null,
    precio double not null,
    stock int not null,
    estado varchar(1) not null,
    primary key PK_codigoProducto (codigoProducto)
);

Create table Venta(	
	codigoVenta int not null auto_increment,
    numeroSerie varchar(55) not null,
    fechaVenta date not null,
    monto double not null,
    estado varchar(1) not null,
	codigoCliente int not null,
	codigoEmpleado int not null,
    primary key PK_codigoVenta (codigoVenta),
    constraint FK_Venta_Cliente foreign key (codigoCliente)
		references Cliente (codigoCliente),
	constraint FK_Venta_Empleado foreign key (codigoEmpleado)
		references Empleado (codigoEmpleado)
);

create table DetalleVenta(
	codigoDetalleVenta int not null auto_increment,
    cantidad int not null,
    precioVenta double not null,
    codigoProducto  int not null,
    codigoVenta int not null,
    primary key PK_codigoDetalleVenta (CodigoDetalleVenta),
    constraint FK_DetalleVenta_Producto foreign key(codigoProducto) 
		references Producto (codigoProducto),
	constraint Fk_codigoDetalleVenta_Venta foreign key (codigoVenta)
		references Venta (codigoVenta)
);




insert into Cliente (DPICliente, nombresCliente, direccionCliente, estado) values ('1234564566666', 'Hector Rodriguez', 'Mixco, Guatemala', '1');
insert into Cliente (DPICliente, nombresCliente, direccionCliente, estado) values ('1579123450108', 'Pedro Juan', 'Guatemala, Guatemala', '1');
insert into Cliente (DPICliente, nombresCliente, direccionCliente, estado) values ('1579987450102', 'Edson Pereira', 'Pinula, Guatemala', '1');
insert into Cliente (DPICliente, nombresCliente, direccionCliente, estado) values ('1579257410107', 'Jose Perez', 'San Juan, Guatemala', '1');

 

insert into Empleado (DPIEmpleado, nombresEmpleado, telefonoEmpleado, estado, usuario) values ('123', 'Hector Rodriguez', '54879632','1', 'hrodriguez');
insert into Empleado (DPIEmpleado, nombresEmpleado, telefonoEmpleado, estado, usuario) values ('157945782', 'Rony Godinez', '43210509','1', 'rgodi');
insert into Empleado (DPIEmpleado, nombresEmpleado, telefonoEmpleado, estado, usuario) values ('157955874', 'Luis Jose', '24587963','1', 'ljose');
insert into Empleado (DPIEmpleado, nombresEmpleado, telefonoEmpleado, estado, usuario) values ('157966352', 'Luisa Cabrera', '36251478','1', 'lcabrera');

 

insert into Producto (nombreProducto, precio, stock, estado) values('Teclado HyperX', 105.00,25,'1');
insert into Producto (nombreProducto, precio, stock, estado) values('Teclado Razer', 74.50,15,'1');
insert into Producto (nombreProducto, precio, stock, estado) values('Laptop Acer Nitro 5', 9850.00,5,'1');
insert into Producto (nombreProducto, precio, stock, estado) values('Monitor Haier 32"', 1225.80,60,'1');

Select * from Cliente;
Select * from Producto;
Select * from Empleado;

 

Select * from Empleado where usuario = 'hrodriguez' and DPIEmpleado = '123';

