/*
Nombre: Héctor Javier Rodríguez Cabrera
Grado: Quinto B
Carné: 2019188
Jornada: Matutina
Fecha de inicio: 12-04-2023
 */
Drop dataBase if exists DBTonysKinal2023;
Create Database DBTonysKinal2023;
use DBTonysKinal2023;

Create table Usuario(
	codigoUsuario int not null auto_increment,
    nombreUsuario varchar (100) not null,
    apellidoUsuario varchar (100) not null,
    usuarioLogin varchar (50) not null,
    contraseña varchar (50) not null,
    primary key PK_codigoUsuario(codigoUsuario)
);

Create table Login(
	usuarioMaster varchar (50) not null,
    passwordLogin varchar (50) not null,
    primary key PK_usuarioMaster(usuarioMaster)
);

Create table Empresas(
	 codigoEmpresa int auto_increment not null,
	 nombreEmpresa varchar(150) not null,
	 direccion varchar(150) not null,
	 telefono varchar(10) not null,
	 primary key PK_codigoEmpresa(codigoEmpresa)
);
 
Create table TipoEmpleado(
	codigoTipoEmpleado int not null auto_increment,
    descripcion varchar(50) not null,
    primary key PK_codigoTipoEmpleado (codigoTipoEmpleado)
);

Create table Empleados(
	codigoEmpleado int auto_increment not null,
	numeroEmpleado int not null,
	apellidosEmpleado varchar(150) not null,
	nombresEmpleado varchar(150) not null,
	direccionEmpleado varchar(150) not null,
	telefonoContacto varchar(12) not null,
	gradoCocinero varchar(50),
	codigoTipoEmpleado int not null,
	primary key PK_codigoEmpleado (codigoEmpleado),
	constraint FK_Empleados_TipoEmpleado foreign key (codigoTipoEmpleado) 
		references TipoEmpleado(codigoTipoEmpleado)
);

Create table TipoPlato(
	codigoTipoPlato int auto_increment not null,
    descripcionTipo varchar(100) not null,
    primary key PK_codigoTipoPlato (codigoTipoPlato)
);

Create table Productos(
	codigoProducto  int auto_increment not null,
	nombreProducto varchar(150) not null,
	cantidad int not null,
	primary key PK_codigoProducto (codigoProducto)
);

Create table Servicios(
	codigoServicio int not null auto_increment,
	fechaServicio date not null,
	tipoServicio varchar(150) not null,
	horaServicio time not null,
	lugarServicio varchar(150) not null,
	telefonoContacto varchar(150) not null,
	codigoEmpresa int not null,
	primary key PK_codigoServicio (codigoServicio),
	constraint FK_Servicio_Empresas foreign key (codigoEmpresa)
		references Empresas (codigoEmpresa)
);

Create table Presupuestos(
	codigoPresupuesto int auto_increment not null,
    fechaSolicitud date not null,
    cantidadPresupuesto decimal(10,2) not null,
    codigoEmpresa int not null,
    primary key PK_codigoPresupuesto (codigoPresupuesto),
    constraint FK_Presupuesto_Empresas foreign key (codigoEmpresa)
		references Empresas(codigoEmpresa)
);

Create table Platos(
	codigoPlato int auto_increment not null,
    cantidad int not null,
    nombrePlato varchar(50) not null,
    descripcionPlato  varchar(150) not null,
    precioPlato decimal(10,2) not null,
    codigoTipoPlato int not null,
    -- tipoPlato codigoTipoPlato int not null
    primary key PK_codigoPlato(codigoPlato),
    constraint FK_Platos_TipoPlato1 foreign key (codigoTipoPlato)
		references TipoPlato (codigoTipoPlato)
);

Create table Productos_has_Platos(
	Productos_codigoProducto int auto_increment not null,
    codigoPlato int not null,
    codigoProducto int not null,
    primary key PK_Productos_codigoProducto (Productos_codigoProducto),
    constraint FK_Producto_has_Platos_Platos1 foreign key (codigoPlato)
		references Platos(codigoPlato),
    constraint FK_Productos_has_Platos_Producto1 foreign key (codigoProducto)
		references Productos(codigoProducto)
	
);

Create table Servicios_has_Platos(
	Servicios_codigoServicio int not null,
    codigoPlato int not null,
    codigoServicio int not null,
    primary key PK_Servicio_codigoServicio(Servicios_codigoServicio),
    constraint FK_Servicios_has_Platos_Servicios1 foreign key (codigoServicio)
		references Servicios(codigoServicio),
	constraint FK_Servicios_has_Platos_Plastos1 foreign key (codigoPlato)
		references Platos(codigoPlato)
);

Create table Servicios_has_Empleados(
	Servicios_codigoServicio int not null,
    codigoServicio int not null,
    codigoEmpleado int not null,
    fechaEvento date not null,
    horaEvento time not null,
    lugarEvento varchar(150) not null,
    primary key PK_Servicios_codigoServicio (Servicios_CodigoServicio),
    constraint FK_Servicios_has_Empleados_Servicios foreign key (codigoServicio)
		references Servicios(codigoServicio),
	constraint FK_Servicios_has_Empleados_Empleados1 foreign key (codigoEmpleado)
		references Empleados(codigoEmpleado)
);

-- ------------------------------------------ PROCEDIMIENTOS ALMACENADOS ------------------------------------------

-- --------------------------- Procedimientos almacenados de AGREGAR ---------------------------

-- Agregar Empresas --
Delimiter $$
	Create procedure sp_AgregarEmpresa(in nombreEmpresa  varchar(150), in direccion varchar(150), in telefono varchar(10))
		begin
			Insert into Empresas(nombreEmpresa, direccion, telefono)
				values (nombreEmpresa, direccion, telefono);
        end $$
Delimiter ;

-- Agregar TipoEmpleado
Delimiter $$
	Create procedure sp_AgregarTipoEmpleado(in descripcion varchar(50))
		begin 
			Insert into TipoEmpleado(descripcion)
				values(descripcion); 
        end$$
Delimiter ;

-- Empleados -- 
Delimiter $$
	Create procedure sp_AgregarEmpleado(in numeroEmpleado int,in apellidosEmpleado varchar(150),in nombresEmpleado varchar(150), in direccionEmpleado varchar(150), in telefonoContacto varchar(8), in gradoCocinero varchar(50), in codigoTipoEmpleado int)
		begin
			Insert into Empleados (numeroEmpleado, apellidosEmpleado, nombresEmpleado, direccionEmpleado, telefonoContacto, gradoCocinero, codigoTipoEmpleado)
				Values(numeroEmpleado, apellidosEmpleado, nombresEmpleado, direccionEmpleado, telefonoContacto, gradoCocinero, codigoTipoEmpleado);
        end $$
Delimiter ;
-- Agregar TipoPlato --
Delimiter $$
	Create procedure sp_AgregarTipoPlato(in descripcionTipo varchar(50))
		begin 
			Insert into TipoPlato(descripcionTipo)
				values(descripcionTipo); 
        end $$
Delimiter ;
-- Agregar Productos --
Delimiter $$
	Create procedure sp_AgregarProducto(in nombreProducto varchar(150), in cantidad int)
		begin
			Insert into Productos (nombreProducto, cantidad)
				Values(nombreProducto, cantidad);
        end $$
Delimiter ;
-- Agregar Servicios --
Delimiter $$
	Create procedure sp_AgregarServicio(in fechaServicio date, in tipoServicio varchar(50), in horaServicio time, lugarServicio varchar(150),in telefonoContacto varchar(150), in codigoEmpresa int)
		begin 
			Insert into Servicios(fechaServicio, tipoServicio, horaServicio, lugarServicio, telefonoContacto, codigoEmpresa)
				values(fechaServicio, tipoServicio, horaServicio, lugarServicio, telefonoContacto, codigoEmpresa); 
        end $$
Delimiter ;
-- Agregar Prespuestos --
Delimiter $$
	Create procedure sp_AgregarPresupuesto(in fechaSolicitud date, in cantidadPresupuesto decimal(10,2), in codigoEmpresa int)
		begin 
			Insert into Presupuestos(fechaSolicitud, cantidadPresupuesto, codigoEmpresa)
				values(fechaSolicitud, cantidadPresupuesto, codigoEmpresa); 
        end $$
Delimiter ;
-- Agregar Platos --
Delimiter $$
	Create procedure sp_AgregarPlato(in cantidad int, in nombrePlato varchar(150), in descripcionPlato varchar(150), in precioPlato decimal(10,2), in codigoTipoPlato int)
		begin 
			Insert into Platos(cantidad, nombrePlato, descripcionPlato, precioPlato, codigoTipoPlato)
				values(cantidad, nombrePlato, descripcionPlato, precioPlato, codigoTipoPlato); 
        end $$
Delimiter ;
-- Agregar Productos_has_Platos --
Delimiter $$
    Create procedure sp_AgregarProducto_Has_Plato (in PR_codPr int, in codPlat int, in codProd int)
        Begin
            Insert into Productos_Has_Platos (Productos_codigoProducto, codigoPlato, codigoProducto)
                values (PR_codPr, codPlat, codPlat);
        End $$
Delimiter ;
-- Agregar Servicios_has_Platos --
Delimiter $$
	Create procedure sp_AgregarSericio_has_Plato(in Servicios_codigoServicio int , in codigoPlato int,
		in codigoServicio int)
        begin
			Insert into Servicios_has_Platos(Servicios_codigoServicio, codigoPlato, codigoServicio)
				Values (Servicios_codigoServicio, codigoPlato, codigoServicio);
        end $$
Delimiter ;
-- Agregar Servicios_has_Empleados --
Delimiter $$
	create procedure sp_AgregarServicio_has_Empleado(in Servicios_codigoServicio int, in codigoServicio int, in codigoEmpleado int , in fechaEvento date ,in  horaEvento time, in lugarEvento varchar(150))
        begin
			Insert into Servicios_has_Empleados(Servicios_codigoServicio, codigoServicio, 
				codigoEmpleado, fechaEvento, horaEvento, lugarEvento) values 
                (Servicios_codigoServicio, codigoServicio, codigoEmpleado, fechaEvento, horaEvento, lugarEvento);
        end $$
Delimiter ;

-- --------------------------- Procedimientos almacenados de ELIMINAR ---------------------------

-- Eliminar Empresas --
Delimiter $$
	Create procedure sp_EliminarEmpresa(in codEmpresa int) 
		begin 
			delete from Empresas 	
				where codigoEmpresa = codEmpresa; 
        end $$
Delimiter ;
-- Eliminar tipoEmpleado --
Delimiter $$
	Create procedure sp_EliminarTipoEmpleado(in codTipoEmpleado int) 
		begin 
			delete from TipoEmpleado 
				where codigoTipoEmpleado = codTipoEmpleado; 
        end $$
Delimiter ;

-- Eliminar Empleados -- 
Delimiter $$
	Create  procedure sp_EliminarEmpleado(in codEmpleado int)
		begin
			delete from Empleados 
            Where codigoEmpleado = codEmpleado;
        end $$
Delimiter ;
-- Eliminar TipoPlato --
Delimiter $$
	Create procedure sp_EliminarTipoPlato(in codTipoPlato int) 
		begin 
			Delete from TipoPlato 
				where codigoTipoPlato = codTipoPlato; 
        end $$
Delimiter ;
-- Eliminar Productos --
Delimiter $$
	Create  procedure sp_EliminarProducto(in codProducto int)
		begin
			delete from Productos 
            where codigoProducto = codProducto;
        end $$
Delimiter ;
-- Eliminar Servicios --
Delimiter $$
	Create procedure sp_EliminarServicio(in codServicio int) 
		begin 
			delete from Servicios 	
				where codigoServicio = codServicio; 
        end $$
Delimiter ;
-- Eliminar Prespuestos --
Delimiter $$
	Create procedure sp_EliminarPresupuesto(in codPresupuesto int) 
		begin 
			delete from Presupuestos 
				where codigoPresupuesto = codPresupuesto; 
        end $$
Delimiter 
-- Eliminar Platos --
Delimiter $$
	Create procedure sp_EliminarPlato(in codPlato int) 
		begin 
			delete from Platos 	
				where codigoPlato = codPlato; 
        end $$
Delimiter ;
-- Eliminar Productos_has_Platos --
Delimiter $$
	Create procedure sp_EliminarProducto_has_Plato(in Productos_codProducto int)
		begin
			delete from Productos_has_Platos 
				Where Productos_codigoProducto = Productos_codProducto; 
        end $$
Delimiter ; 
-- Eliminar Servicios_has_Platos --
Delimiter $$
	Create procedure sp_EliminarServicio_has_Plato(in Servicios_codProducto int)
		begin
			delete from Servicios_has_Platos 
				where Servicios_codigoProducto = Servicios_codProducto; 
        end $$
Delimiter ;
-- Eliminar Servicios_has_Empleados --
Delimiter $$
	Create procedure sp_EliminarServicio_has_Empleado(in Servicios_codServicio int )
		begin
			delete from Servicios_has_Empleados 
				where Servicios_codigoServicio = Servicios_codServicio; 
        end $$
Delimiter ; 

-- --------------------------- Procedimientos almacenados de LISTAR ---------------------------

-- Listar Empresas --
Delimiter $$
	Create procedure sp_ListarEmpresas()
	begin 
		Select 
			E.codigoEmpresa, 
			E.nombreEmpresa, 
            E.direccion, 
            E.telefono
            from Empresas E; 
    end $$
Delimiter ;
-- Listar tipoEmpleado --
Delimiter $$
	Create procedure sp_ListarTipoEmpleados()
	begin 
		Select 
			TE.codigoTipoEmpleado, 
            TE.descripcion
            from TipoEmpleado TE; 
    end $$
Delimiter ;
-- Listar Empleados -- 
Delimiter $$
	Create procedure sp_ListarEmpleados()
		begin
			Select 
				E.codigoEmpleado,
				E.numeroEmpleado, 
                E.apellidosEmpleado, 
                E.nombresEmpleado, 
                E.direccionEmpleado, 
                E.telefonoContacto, 
                E.gradoCocinero, 
                E.codigoTipoEmpleado
                from Empleados E;
        end $$
Delimiter ;
-- Listar TipoPlato --
Delimiter $$
	Create procedure sp_ListarTipoPlatos()
	begin 
		Select 
			T.codigoTipoPlato, 
            T.descripcionTipo
            from TipoPlato T; 
    end $$
Delimiter ;
-- Listar Productos --
Delimiter $$
	Create procedure sp_ListarProductos()
		begin
			Select 
				codigoProducto,
				nombreProducto,
                cantidad
                from Productos ;
        end $$
Delimiter ;
-- Listar Servicios --
Delimiter $$
	Create procedure sp_ListarServicios()
	begin 
		Select 
			S.codigoServicio,
			S.fechaServicio, 
            S.tipoServicio, 
            S.horaServicio, 
            S.lugarServicio, 
            S.telefonoContacto, 
            S.codigoEmpresa
            from Servicios S; 
    end $$
Delimiter ;
-- Listar Prespuestos --
Delimiter $$
	Create procedure sp_ListarPresupuestos()
	begin 
		Select 
			Pre.codigoPresupuesto, 
            Pre.fechaSolicitud, 
            Pre.cantidadPresupuesto, 
            Pre.codigoEmpresa
            from Presupuestos Pre; 
    end $$
Delimiter ;
-- Listar Platos --
Delimiter $$
	Create procedure sp_ListarPlatos()
	begin 
		Select 
			P.codigoPlato, 
            P.cantidad, 
            P.nombrePlato,
            P.descripcionPlato, 
            P.precioPlato, 
            P.codigoTipoPlato
            from Platos P; 
    end $$
Delimiter ;
-- Listar Productos_has_Platos --
Delimiter $$
	Create procedure sp_ListarProductos_has_Platos()
		begin
			Select 
				PP.Productos_codigoProducto, 
				PP.codigoPlato, 
				PP.codigoProducto
				from Productos_has_Platos PP; 
        end $$
Delimiter ; 
-- Listar Servicios_has_Platos --
Delimiter $$
	Create procedure sp_ListarServicios_has_Platos()
		begin
			Select 
				Servicios_codigoServicio,
                codigoPlato, 
                codigoServicio
                from Servicios_has_Platos ; 
        end $$
Delimiter ;
-- Listar Servicios_has_Empleados --
Delimiter $$
	Create procedure sp_ListarServicios_has_Empleados()
		begin
			Select
            SE.Servicios_codigoServicio,
            SE.codigoServicio, 
            SE.codigoEmpleado,
            SE.fechaEvento,
            SE.horaEvento,
            SE.lugarEvento
            from Servicios_has_Empleados SE; 
        end $$
Delimiter ; 

-- --------------------------- Procedimientos almacenados de BUSCAR ---------------------------

-- Buscar Empresas --
Delimiter $$
	Create procedure sp_BuscarEmpresa(in codEmpresa int)
		begin 
			Select 
				E.codigoEmpresa, 
				E.nombreEmpresa, 
				E.direccion,
				E.telefono
				from Empresas E where E.codigoEmpresa = codEmpresa; 
        end $$
Delimiter ;
-- Buscar tipoEmpleado --
Delimiter $$
	Create procedure sp_BuscarTipoEmpleado(in codTipoEmpleado int)
	begin 
		Select 
			T.codigoTipoEmpleado,
            T.descripcion
            from TipoEmpleado T where T.codigoTipoEmpleado = codTipoEmpleado; 
    end $$
Delimiter ;
-- Buscar Empleados -- 
Delimiter $$
	Create procedure sp_BuscarEmpleado(in codEmpleado int)
		begin
			Select 
				E.codigoEmpleado, 
				E.numeroEmpleado, 
                E.apellidosEmpleado, 
                E.nombresEmpleado, 
                E.direccionEmpleado, 
                E.telefonoContacto, 
                E.gradoCocinero, 
                E.codigoTipoEmpleado
                from Empleados E  where E.codigoEmpleado = codEmpleado;
        end $$
Delimiter ;
-- Buscar TipoPlato --
Delimiter $$
	Create procedure sp_BuscarTipoPlato(in codTipoPlato int)
	Begin 
		Select 
			T.codigoTipoPlato,
            T.descripcionTipo
            from TipoPlato T where T.codigoTipoPlato = codTipoPlato; 
    end $$
Delimiter ;
-- Buscar Productos --
Delimiter $$
	Create procedure sp_BuscarProducto(in codProducto int)
		begin
			Select 
				codigoProducto,
				nombreProducto, 
                cantidad
                from Productos  where codigoProducto = codProducto;
        end $$
Delimiter ;
-- Buscar Servicios --
Delimiter $$
	Create procedure sp_BuscarServicio(in codServicio int)
	begin 
		Select 
			S.codigoServicio,
			S.fechaServicio, 
            S.tipoServicio, 
            S.horaServicio, 
            S.lugarServicio, 
            S.telefonoContacto, 
            S.codigoEmpresa
            from Servicios S where S.codigoServicio = codServicio; 
    end $$
Delimiter ;
-- Buscar Prespuestos --
Delimiter $$
	Create procedure sp_BuscarPresupuesto(in codPresupuesto int)
		Begin 
			Select 
				Pre.codigoPresupuesto, 
				Pre.fechaSolicitud, 
				Pre.cantidadPresupuesto, 
				Pre.codigoEmpresa
				From Presupuestos Pre where Pre.codigoPresupuesto = codPresupuesto; 
        end $$ 
Delimiter ;

-- Buscar Platos --
Delimiter $$
	Create procedure sp_BuscarPlato(in codPlato int)
	begin 
		Select 
			P.codigoPlato, 
            P.cantidad, 
            P.nombrePlato,
            P.descripcionPlato, 
            P.precioPlato, 
            P.codigoTipoPlato
            from Platos P where P.codigoPlato = codPlato; 
    end $$
Delimiter ;
-- Buscar Productos_has_Platos --
Delimiter $$
	Create procedure sp_BuscarProducto_has_Plato(in Produc_codProducto int)
		begin
			Select 
				PP.codigoPlato, 
				PP.codigoProducto
				from Productos_has_Platos PP where PP.Productos_codigoProducto = Produc_codProducto; 
        end $$
Delimiter ; 
-- Buscar Servicios_has_Platos --
Delimiter $$
	Create procedure sp_BuscarServicio_has_Plato (in Servi_codProducto int)
		begin
			Select 
                SP.codigoPlato, 
                SP.codigoServicio
                from Servicios_has_Platos SP where SP.Servicios_codigoProducto = Servi_codProducto; 
        end $$
Delimiter ;
-- Buscar Servicios_has_Empleados --
Delimiter $$
	Create procedure sp_BuscarServicio_has_Empleado(in Servi_codServicio int)
		begin
			Select
            SE.codigoServicio, 
            SE.codigoEmpleado,
            SE.fechaEvento,
            SE.horaEvento,
            SE.lugarEvento
            from Servicios_has_Empleados SE where SE.Servicios_codigoServicio = Servi_codServicio; 
        end $$
Delimiter ; 
-- --------------------------- Procedimientos almacenados de EDITAR ---------------------------

-- Editar Empresas --
Delimiter $$
	Create procedure sp_EditarEmpresa(in codEmpresa int, in nomEmpresa varchar(150), in direcci varchar(105), in tel varchar (10))
		begin 
			Update Empresas E
				set 
				E.nombreEmpresa = nomEmpresa, 
                E.direccion = direcci,
                E.telefono = tel where E.codigoEmpresa = codEmpresa;  
        end $$
Delimiter ;
-- Editar tipoEmpleado --
Delimiter $$
	Create procedure sp_EditarTipoEmpleado(in codTipoEmpleado int, in descri varchar(50))
		begin 
			Update TipoEmpleado TE
				set 
				TE.descripcion = descri where TE.codigoTipoEmpleado = codTipoEmpleado;  
        end $$
Delimiter ;
-- Editar Empleados -- 
Delimiter $$
	Create procedure sp_EditarEmpleado(in codEmpleado int, in numEmpleado int, in apeEmpleado varchar(150), 
										in nomEmpleado varchar(150), in direcciEmpleado varchar(150), in telCon varchar(8), 
                                        in gradoCoci varchar(50),in codTipoEmpleado int)
        begin
			Update Empleados E
				set
                E.numeroEmpleado = numEmpleado,
                E.apellidosEmpleado = apeEmpleado, 
                E.nombresEmpleado = nomEmpleado, 
                E.direccionEmpleado = direcciEmpleado,
                E.telefonoContacto = telCon,
                E.gradoCocinero = gradoCoci,
                E.codigoTipoEmpleado = codTipoEmpleado where E.codigoEmpleado = codEmpleado; 	
        end $$
 Delimiter ;
 
-- Editar TipoPlato --
Delimiter $$
	Create procedure sp_EditarTipoPlato(in codTipoPlato int, in descripTipo varchar(50))
		begin 
			Update TipoPlato TP
				set 
				TP.descripcionTipo = descripTipo where TP.codigoTipoPlato =  codTipoPlato;  
        end $$
Delimiter ;
-- Editar Productos --
Delimiter $$
	Create procedure sp_EditarProducto(in codProducto int, in nomProducto varchar(150), in canti int)	
		begin
			Update Productos
				set
                    nombreProducto = nomProducto, 
                    cantidad = canti where codigoProducto = codProducto;
		end $$
Delimiter ;
-- Editar Servicios --
Delimiter $$
	Create procedure sp_EditarServicio(in codServicio int, in fServi date, in tServi varchar(150), in hServi time, in lServi varchar(150), in tContacto varchar(150), in codEmpre int)
		begin 
			Update Servicios S
				set 
				S.fechaServicio = fServi, 
				S.tipoServicio = tServi, 
				S.horaServicio = hServi, 
				S.lugarServicio = lServi, 
				S.telefonoContacto = tContacto,
                S.codigoEmpresa = codEmpre where S.codigoServicio =  codServicio;  
        end $$
Delimiter ;
-- Editar Prespuestos --
Delimiter $$
	Create procedure sp_EditarPresupuesto(in codPres int, in fechSoli date, in cantPres decimal(10,2), in codEmp int)
		begin 
			  Update Presupuestos Pre
					set
                    Pre.fechaSolicitud = fechSoli,
                    Pre.cantidadPresupuesto = cantPres,
                    Pre.codigoEmpresa = codEmp
                    where Pre.codigoPresupuesto = codPres;
                    
        end $$
Delimiter ;
-- Editar Platos --
Delimiter $$
	Create procedure sp_EditarPlato(in codPlato int, in cant int, in nomPlato varchar(150), in descrip varchar(150), in pPlato decimal(10,2),in codTipoPlato int)
		begin 
			Update Platos P
				set  
				P.cantidad = cant, 
				P.nombrePlato = nomPlato,
				P.descripcionPlato = descrip, 
				P.precioPlato = pPlato ,
                P.codigoTipoPlato = codTipoPlato where P.codigoPlato = codPlato; 	
                
        end $$
Delimiter ;


-- Editar Productos_has_Platos --
Delimiter $$
	Create procedure sp_EditarProducto_has_Plato(in Productos_codProducto int, in codPlato int, in codProducto int)
		begin
			update Productos_has_Platos PP
				set 
					PP.codigoPlato = codPlato, 
                    PP.codigoProducto = codProducto where PP.Productos_codigoProducto = Productos_codProducto;
        end $$
Delimiter ; 
-- Editar Servicios_has_Platos --
Delimiter $$
	Create Procedure sp_EditarServicio_has_Plato(in Servicios_codProducto int , in codPlato int, in codServicio int)
        begin
			Update Servicios_has_Platos SP
				set 
					SP.codigoPlato = codPlato, 
					SP.codigoServicio = codServicio where SP.Servicios_codigoProducto = Servicios_codProducto; 					
        end $$
Delimiter ; 
-- Editar Servicios_has_Empleados --
Delimiter $$
	Create procedure sp_EditarServicio_has_Empleado(in Servicios_codServicio int, in fEvento date, 
    in  hEvente time, in lEvente varchar(150))
        Begin
			Update Servicios_has_Empleados SE 
				set
					SE.fechaEvento = fEvento, 
                    SE.horaEvento = hEvente, 
                    SE.lugarEvento = lEvente
                    where SE.Servicios_codigoServicio = Servicios_codServicio; 
        end $$
Delimiter ; 

-- -------------------------------------------------------------- DATOS --------------------------------------------------------------



-- USUARIO SP --
Delimiter $$
	Create procedure sp_AgregarUsuario(in nombreUsuario varchar(100), in apellidoUsuario varchar(100),
										in usuarioLogin varchar(50), in contraseña varchar(50))
		begin
			Insert into Usuario (nombreUsuario, apellidoUsuario, usuarioLogin, contraseña)
				Values(nombreUsuario, apellidoUsuario, usuarioLogin, contraseña);
        end $$
Delimiter ;

call sp_AgregarUsuario('Juan','Monzon','que se yo','1234');

Delimiter $$
	Create procedure sp_ListarUsuarios()
		begin
			select
				U.codigoUsuario,
                U.nombreUsuario,
                U.apellidoUsuario,
                U.usuarioLogin,
                U.contraseña
            from Usuario U; 
        end $$
Delimiter ;




-- ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'admin';
-- FLUSH PRIVILEGES;

CALL sp_AgregarEmpresa('Sabores del Lago', 'Zona 10, Ciudad de Guatemala', '5551-1111');
CALL sp_AgregarEmpresa('El Rincon Chapin', 'Antigua Guatemala', '5552-2222');
CALL sp_AgregarEmpresa('La Fonda de la Abuela', 'Zona 4, Quetzaltenango', '5553-3333');
CALL sp_AgregarEmpresa('Sabor y Tradicion', 'Zona 1, Chichicastenango', '5554-4444');
CALL sp_AgregarEmpresa('El Palmar', 'Flores, Peten', '5555-5555');

CALL sp_AgregarTipoEmpleado('Cocinero principal');
CALL sp_AgregarTipoEmpleado('Ayudante de cocina');
CALL sp_AgregarTipoEmpleado('Chef de repostería');
CALL sp_AgregarTipoEmpleado('Cocinero de parrilla');
CALL sp_AgregarTipoEmpleado('Sous Chef');

CALL sp_AgregarEmpleado(1, 'Gonzalez', 'Juan', 'Zona 1, Ciudad de Guatemala', '12345678', 'Chef Ejecutivo', 1);
CALL sp_AgregarEmpleado(2, 'Martínez', 'Luisa', 'Zona 2, Ciudad de Guatemala', '98765432', 'Sous Chef', 2);
CALL sp_AgregarEmpleado(3, 'Perez', 'Ana', 'Zona 3, Ciudad de Guatemala', '55555555', 'Chef de Partie', 3);
CALL sp_AgregarEmpleado(4, 'Lopez', 'Carlos', 'Zona 4, Ciudad de Guatemala', '99999999', 'Commis Chef', 4);
CALL sp_AgregarEmpleado(5, 'Ramirez', 'María', 'Zona 5, Ciudad de Guatemala', '11111111', 'Chef Repostero', 5);

CALL sp_AgregarTipoPlato('Entrantes');
CALL sp_AgregarTipoPlato('Platos Principales');
CALL sp_AgregarTipoPlato('Postres');
CALL sp_AgregarTipoPlato('Ensaladas');
CALL sp_AgregarTipoPlato('Sopas');

CALL sp_AgregarProducto('Arroz', 10);
CALL sp_AgregarProducto('Carne', 5);
CALL sp_AgregarProducto('Lechuga', 8);
CALL sp_AgregarProducto('Tomate', 15);
CALL sp_AgregarProducto('Queso', 20);

CALL sp_AgregarServicio('2023-06-01', 'Banquete de Bodas', '12:00:00', 'Zona 10, Guatemala', '1234-5678', 1);
CALL sp_AgregarServicio('2023-06-02', 'Catering para Evento Corporativo', '14:00:00', 'Zona 4, Guatemala', '9876-5432', 2);
CALL sp_AgregarServicio('2023-06-03', 'Buffet para Fiesta de Cumpleaños', '16:00:00', 'Zona 14, Guatemala', '5555-5555', 3);
CALL sp_AgregarServicio('2023-06-04', 'Servicio de Catering para Bautizo', '18:00:00', 'Zona 7, Guatemala', '9999-9999', 4);
CALL sp_AgregarServicio('2023-06-05', 'Banquete para Graduación', '20:00:00', 'Zona 9, Guatemala', '1111-1111', 5);

CALL sp_AgregarPresupuesto('2023-06-01', 1000.00, 1);
CALL sp_AgregarPresupuesto('2023-06-02', 2000.00, 2);
CALL sp_AgregarPresupuesto('2023-06-03', 3000.00, 3);
CALL sp_AgregarPresupuesto('2023-06-04', 4000.00, 4);
CALL sp_AgregarPresupuesto('2023-06-05', 5000.00, 5);

CALL sp_AgregarPlato(2, 'Pasta Alfredo', 'Deliciosa pasta con salsa Alfredo y pollo', 10.99, 1);
CALL sp_AgregarPlato(3, 'Sushi Mixto', 'Variedad de rollos de sushi con pescado fresco', 15.99, 2);
CALL sp_AgregarPlato(4, 'Ceviche de Camaron', 'Refrescante ceviche de camaron con limon y cilantro', 20.99, 3);
CALL sp_AgregarPlato(5, 'Filete de Res a la Parrilla', 'Jugoso filete de res acompañado de vegetales asados', 25.99, 4);
CALL sp_AgregarPlato(6, 'Tiramisu', 'Clasico postre italiano con capas de bizcocho y crema de mascarpone', 30.99, 5);

 CALL sp_AgregarProducto_has_Plato(1, 2, 1);
 CALL sp_AgregarProducto_has_Plato(2, 1, 2);
 CALL sp_AgregarProducto_has_Plato(3, 3, 3);
 CALL sp_AgregarProducto_has_Plato(4, 4, 4);
 CALL sp_AgregarProducto_has_Plato(5, 5, 5);

CALL sp_AgregarServicio_has_Empleado(1, 1, 1, '2023-06-01', '12:00:00', 'Zona 10, Ciudad de Guatemala');
CALL sp_AgregarServicio_has_Empleado(2, 2, 2, '2023-06-02', '14:00:00', 'Antigua Guatemala');
CALL sp_AgregarServicio_has_Empleado(3, 3, 3, '2023-06-03', '16:00:00', 'Lago de Atitlan');
CALL sp_AgregarServicio_has_Empleado(4, 4, 4, '2023-06-04', '18:00:00', 'Semuc Champey');
CALL sp_AgregarServicio_has_Empleado(5, 5, 5, '2023-06-05', '20:00:00','Tikal, Peten');
 
CALL sp_AgregarSericio_has_Plato(1, 1, 1);
CALL sp_AgregarSericio_has_Plato(2, 2, 2);
CALL sp_AgregarSericio_has_Plato(3, 3, 3);
CALL sp_AgregarSericio_has_Plato(4, 4, 4);
CALL sp_AgregarSericio_has_Plato(5, 5, 5);



